package com.example.realestate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealStateListingApplicationTests {

	@Test
	void contextLoads() {
	}

}
