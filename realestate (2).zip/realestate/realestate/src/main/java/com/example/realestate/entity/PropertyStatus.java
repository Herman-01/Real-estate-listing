package com.example.realestate.entity;

public enum PropertyStatus {
    AVAILABLE,
    SOLD,
    UNDER_CONTRACT
}
